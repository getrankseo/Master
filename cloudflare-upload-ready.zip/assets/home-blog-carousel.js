(()=>{
 const root=document.querySelector('.home-blog-carousel'); if(!root)return;
 const track=root.querySelector('.home-blog-track'); const prev=root.querySelector('[data-carousel-prev]'); const next=root.querySelector('[data-carousel-next]');
 const step=()=>{const card=track.querySelector('.home-blog-card');if(!card)return track.clientWidth*.85;const gap=parseFloat(getComputedStyle(track).gap)||0;return card.getBoundingClientRect().width+gap;};
 prev?.addEventListener('click',()=>track.scrollBy({left:-step(),behavior:'smooth'}));
 next?.addEventListener('click',()=>track.scrollBy({left:step(),behavior:'smooth'}));
 const update=()=>{const max=track.scrollWidth-track.clientWidth-2;prev.disabled=track.scrollLeft<=2;next.disabled=track.scrollLeft>=max;prev.setAttribute('aria-disabled',prev.disabled?'true':'false');next.setAttribute('aria-disabled',next.disabled?'true':'false');};
 track.addEventListener('scroll',()=>requestAnimationFrame(update),{passive:true});window.addEventListener('resize',update);update();
})();
