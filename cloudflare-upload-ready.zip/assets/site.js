
const navToggle=document.querySelector('.nav-toggle');
const mainNav=document.querySelector('.main-nav');
if(navToggle&&mainNav){navToggle.addEventListener('click',()=>{const open=mainNav.classList.toggle('open');navToggle.setAttribute('aria-expanded',open?'true':'false')})}
document.querySelectorAll('.nav-dropdown>button').forEach(btn=>{btn.addEventListener('click',()=>{const parent=btn.closest('.nav-dropdown');const open=parent.classList.toggle('open');btn.setAttribute('aria-expanded',open?'true':'false')})});
document.addEventListener('click',e=>{document.querySelectorAll('.nav-dropdown.open').forEach(d=>{if(!d.contains(e.target)){d.classList.remove('open');const b=d.querySelector('button');if(b)b.setAttribute('aria-expanded','false')}})});
